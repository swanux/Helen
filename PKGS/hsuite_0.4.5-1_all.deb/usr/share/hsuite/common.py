import os
p = 'output'
status = 'Install'#'installORremove'
CA = 'current action'
version = 'HSuite v0.4 | Extended Edition'
#comm = 'xdg-open "https://github.com/swanux/hsuite/issues/new/choose"'
#fbakker = 'user=$("logname") && runuser -l $user -c %s' % comm
txt1 = 'Coming in future Beta releases...'
distro = 'common distro'
label = 'description'
rmMsg = 'while removing'
rmdMsg = 'when removed'
inMsg = 'while installing'
indMsg = 'when installed'
kbTime = 1 # How long will it take?
distroSpec = 'aptoraur'
user = 'the currently logged in non-root user'
doIt = False
text = 'Description'
stack = 'GTK base'
name = 'appName'
t1 = 'test'
# appname_value = 'installORremove'
