#!/bin/sh +e

/usr/share/hsuite/HSuite.py
